/**hola.c
*/

#include "types.h"
#include "user.h"

int main(int argc,char *argv[]){
	printf(1,"HOLA MUNDO xv6, %d\n", argc);
	exit();
}/*end main()*/
