/**hola.c
*/

#include "types.h"
#include "user.h"

int f(int);
int main(int argc,char *argv[]){
	printf(1,"HOLA MUNDO xv6, %d\n", argc);
	printf(1,"f(10)=%d\n",f(10));
	printf(1,"main= 0x%p\n",dummy(main));
	printf(1,"main= 0x%p\n",dummy(f));
	exit();
}/*end main()*/

int f(int a){
	return a+1;
}


