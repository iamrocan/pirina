/**hola.c
*/

#include "types.h"
#include "user.h"

int main(int argc,char *argv[]){
	printf(1,"HOLA MUNDO xv6, %d\n", argc);
	printf(1,"main= 0x%p\n",dummy(main));
	exit();
}/*end main()*/
